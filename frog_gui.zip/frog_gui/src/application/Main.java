package application;  
import javafx.application.Application;  
import javafx.scene.Group;  
import javafx.scene.Scene;  
import javafx.scene.paint.Color;  
import javafx.scene.shape.Ellipse;  
import javafx.stage.Stage;  
import javafx.scene.shape.Rectangle;


public class Main extends Application{  
  
    @Override  
    public void start(Stage primaryStage) throws Exception {  
        // TODO Auto-generated method stub  
    primaryStage.setTitle("FROGS AND TOADS");  
    Group group = new Group();     
    Rectangle rectangle = new Rectangle();
    rectangle.setX(47.0f); 
    rectangle.setY(190.0f); 
    rectangle.setWidth(20.0f); 
    rectangle.setHeight(30.0f);
    rectangle.setFill(javafx.scene.paint.Color.RED);
    Ellipse elipse = new Ellipse();
    elipse.setCenterX(60);  
    elipse.setCenterY(250);  
    elipse.setRadiusX(20);  
    elipse.setRadiusY(20); 
    Rectangle rectangle2 = new Rectangle();
    rectangle2.setX(110.0f); 
    rectangle2.setY(190.0f); 
    rectangle2.setWidth(20.0f); 
    rectangle2.setHeight(30.0f);
    rectangle2.setFill(javafx.scene.paint.Color.RED);
    Ellipse elipse2 = new Ellipse();  
    elipse2.setCenterX(120);  
    elipse2.setCenterY(250);  
    elipse2.setRadiusX(20);  
    elipse2.setRadiusY(20); 
    Rectangle rectangle3 = new Rectangle();
    rectangle3.setX(170.0f); 
    rectangle3.setY(190.0f); 
    rectangle3.setWidth(20.0f); 
    rectangle3.setHeight(30.0f);
    rectangle3.setFill(javafx.scene.paint.Color.RED);
    Ellipse elipse3 = new Ellipse();  
    elipse3.setCenterX(180);  
    elipse3.setCenterY(250);  
    elipse3.setRadiusX(20);  
    elipse3.setRadiusY(20); 
    Ellipse elipse4 = new Ellipse();  
    elipse4.setCenterX(240);  
    elipse4.setCenterY(250);  
    elipse4.setRadiusX(20);  
    elipse4.setRadiusY(20); 
    Rectangle rectangle4 = new Rectangle();
    rectangle4.setX(287.0f); 
    rectangle4.setY(190.0f); 
    rectangle4.setWidth(20.0f); 
    rectangle4.setHeight(30.0f);
    rectangle4.setFill(javafx.scene.paint.Color.GREEN);
    Ellipse elipse5 = new Ellipse();  
    elipse5.setCenterX(300);  
    elipse5.setCenterY(250);  
    elipse5.setRadiusX(20);  
    elipse5.setRadiusY(20); 
    Rectangle rectangle5 = new Rectangle();
    rectangle5.setX(350.0f); 
    rectangle5.setY(190.0f); 
    rectangle5.setWidth(20.0f); 
    rectangle5.setHeight(30.0f);
    rectangle5.setFill(javafx.scene.paint.Color.GREEN);
    Ellipse elipse6 = new Ellipse();  
    elipse6.setCenterX(360);  
    elipse6.setCenterY(250);  
    elipse6.setRadiusX(20);  
    elipse6.setRadiusY(20); 
    Rectangle rectangle6 = new Rectangle();
    rectangle6.setX(410.0f); 
    rectangle6.setY(190.0f); 
    rectangle6.setWidth(20.0f); 
    rectangle6.setHeight(30.0f);
    rectangle6.setFill(javafx.scene.paint.Color.GREEN);
    Ellipse elipse7 = new Ellipse();  
    elipse7.setCenterX(420);  
    elipse7.setCenterY(250);  
    elipse7.setRadiusX(20);  
    elipse7.setRadiusY(20);
    group.getChildren().addAll(rectangle);
    group.getChildren().addAll(elipse);
    group.getChildren().addAll(rectangle2);
    group.getChildren().addAll(elipse2);
    group.getChildren().addAll(rectangle3);
    group.getChildren().addAll(elipse3);
    group.getChildren().addAll(elipse4);
    group.getChildren().addAll(rectangle4);
    group.getChildren().addAll(elipse5);
    group.getChildren().addAll(rectangle5);
    group.getChildren().addAll(elipse6);
    group.getChildren().addAll(rectangle6);
    group.getChildren().addAll(elipse7);
    Scene scene = new Scene(group,500,500,Color.SKYBLUE);  
    primaryStage.setScene(scene);
    primaryStage.show();  
}  
public static void main(String[] args) {  
    launch(args);  
}
}