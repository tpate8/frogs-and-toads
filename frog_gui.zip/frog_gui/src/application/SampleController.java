package application;

public class SampleController {
	
}
